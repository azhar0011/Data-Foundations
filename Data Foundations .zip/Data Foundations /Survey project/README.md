                     Analyze Survey Data

Project Overview:

In this project, you will analyze a real dataset about current Udacity students across a number of programs, so it isn't perfect. It is a little messy (some things are input incorrectly, others are missing). You will need to decide how to analyze the data and then communicate your findings about it. You will use spreadsheets to make your analysis easier (please do not analyze by hand - it will take forever!).



Tools:
Excel.