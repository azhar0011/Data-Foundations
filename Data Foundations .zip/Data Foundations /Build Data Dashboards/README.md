                     Build Data Dashboards

Project Description
In this project, you'll create visualizations to reveal insights from a data set. You will create data visualizations that tell a story or highlight patterns in the data set. Your work should be a reflection of the theory and practice of data visualization, such as visual encodings, design principles, and effective communication.

The data set:
* Flight Delays and Cancellations

Questions:
1)What are the worst airlines that has more delay? 
2)What are the most airline have a delay in the departure? 
3)What the total number of flights cancelled? 
4)More reason to cancel flights? 
5)What is the most cancellations in the month? 

Tools:
Tableau Public / Tableau Desktop
